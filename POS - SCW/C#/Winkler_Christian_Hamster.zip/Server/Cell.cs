﻿using Comms;

namespace Server
{
    public class Cell
    {
        public Direction Face { get; set; }
        public bool Colored { get; set; }
    }
}
