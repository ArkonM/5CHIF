﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Security.Cryptography.Xml;
using System.Windows.Interop;

namespace TicTacToe
{
    
    public class Field : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, e);
        }

        public SolidColorBrush _color
        {
            get { return _color; }
            set
            {
                _color = value;
                OnPropertyChanged(new PropertyChangedEventArgs("color"));
            }
        }
    }





    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Transfer t;
        AutoResetEvent sendMSGEvent = new AutoResetEvent(false);
        AutoResetEvent clicked = new AutoResetEvent(false);
        private int _selectedIndex;

        public MainWindow()
        {
            InitializeComponent();
        }

        public List<Field> Fields { get; set; } = new List<Field>();
        public int Size { get; set; } = 3;



        void runServer()
        {
            TcpListener listener = null;
            try
            {
                listener = new TcpListener(IPAddress.Any, 12345);
                listener.Start();
            }
            catch (SocketException e)
            {
                MessageBox.Show(e.ErrorCode + ": " + e.Message);
                Environment.Exit(e.ErrorCode);
            }

            TcpClient client = null;
            NetworkStream netStream = null;
            client = listener.AcceptTcpClient();

            try
            {
                var random = new Random();
                // Generiere eine Client Verbindung
                netStream = client.GetStream();
                //ReceiverLogin r = new ReceiverLogin();
                Transfer t = new Transfer(client);
                t.Start();


                Play config = new Play { type = MessageType.CONFIG, Config = new Config { fieldSize = Size, startPlayer = random.Next(2) == 1 } };

                t.Send(config);

                fillField();
                MessageBox.Show("connected client");

                if (config.Config.startPlayer == true)
                {
                    startFirst(t);
                }
                else
                {
                    startSecond(false, t);
                }

            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        void runClient()
        {
            TcpClient client = null;
            try
            {
                client = new TcpClient("localhost", 12345);
                t = new Transfer(client);

                t.Start();
                t.auto.WaitOne();

                Size = t.m.Config.fieldSize;

                fillField();
                MessageBox.Show("connected server");

                if (t.m.Config.startPlayer == true)
                {
                    startSecond(true, t);
                }
                else
                {
                    startFirst(t);
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }



        void startFirst(Transfer t)
        {
            while (true)
            {
                clicked.WaitOne();

                this.Dispatcher.BeginInvoke(
                System.Windows.Threading.DispatcherPriority.Normal
                , new System.Windows.Threading.DispatcherOperationCallback(delegate
                {
                    PlayingField.IsEnabled = false;
                    return null;
                }), null);

                try
                {
                    Play m = new Play() { type = MessageType.PLAYFIELD, index = new PlayfieldIndex() { indx = _selectedIndex } };
                    t.Send(m);
                }
                catch (Exception ex)
                {
                    t.Stop();
                    MessageBox.Show(ex.ToString());
                }

                t.auto.WaitOne();
                this.Dispatcher.BeginInvoke(
                System.Windows.Threading.DispatcherPriority.Normal
                , new System.Windows.Threading.DispatcherOperationCallback(delegate
                {
                    ListBoxItem? selectedItemContainer = PlayingField.ItemContainerGenerator.ContainerFromItem(PlayingField.Items[t.m.index.indx]) as ListBoxItem;
                    if (selectedItemContainer != null)
                    {
                        // Set the background color of the container element
                        selectedItemContainer.Background = Brushes.Pink;
                        
                    }

                    return null;
                }), null);

                this.Dispatcher.BeginInvoke(
                System.Windows.Threading.DispatcherPriority.Normal
                , new System.Windows.Threading.DispatcherOperationCallback(delegate
                {
                    PlayingField.IsEnabled = true;
                    return null;
                }), null);
            }
            
        }

        void startSecond(bool whoStarts, Transfer t)
        {
            switch (whoStarts)
            {
                case true: MessageBox.Show("Ready to play!\nServer has to do the first shot!"); break;
                case false: MessageBox.Show("Ready to play!\nClient has to do the first shot!"); break;
            }

            this.Dispatcher.BeginInvoke(
                System.Windows.Threading.DispatcherPriority.Normal
                , new System.Windows.Threading.DispatcherOperationCallback(delegate
                {
                    PlayingField.IsEnabled = false;
                    return null;
                }), null);

            while (true)
            {
                t.auto.WaitOne();

                this.Dispatcher.BeginInvoke(
                System.Windows.Threading.DispatcherPriority.Normal
                , new System.Windows.Threading.DispatcherOperationCallback(delegate
                {
                    ListBoxItem? selectedItemContainer = PlayingField.ItemContainerGenerator.ContainerFromItem(PlayingField.Items[t.m.index.indx]) as ListBoxItem;
                    if (selectedItemContainer != null)
                    {
                        // Set the background color of the container element
                        selectedItemContainer.Background = Brushes.Pink;

                    }

                    PlayingField.IsEnabled = true;
                    return null;
                }), null);


                clicked.WaitOne();

                this.Dispatcher.BeginInvoke(
                System.Windows.Threading.DispatcherPriority.Normal
                , new System.Windows.Threading.DispatcherOperationCallback(delegate
                {
                    PlayingField.IsEnabled = false;
                    return null;
                }), null);

                try
                {
                    Play m = new Play() { type = MessageType.PLAYFIELD, index = new PlayfieldIndex() { indx = _selectedIndex } };
                    t.Send(m);
                }
                catch (Exception ex)
                {
                    t.Stop();
                    MessageBox.Show(ex.ToString());
                }
            }
        }


        void fillField()
        {
            try
            {
                this.Dispatcher.BeginInvoke(
                System.Windows.Threading.DispatcherPriority.Normal
                , new System.Windows.Threading.DispatcherOperationCallback(delegate
                {
                    //eigentliche Änderungen
                    for (int i = 0; i < Size; i++)
                    {
                        for (int j = 0; j < Size; j++)
                        {
                            Fields.Add(new Field());
                        }
                    }
                    this.DataContext = this;
                    return null;
                }), null);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ServerClientDialog dialog1 = new ServerClientDialog();
            dialog1.ShowDialog();
            if (dialog1.DialogResult == true)
            {
                if (dialog1.isServer)
                {
                    Title.Content = "TicTacToe - Server";

                    MatchfieldSize dialog2 = new MatchfieldSize();
                    dialog2.ShowDialog();
                    if (dialog2.DialogResult == true)
                    {
                        int.TryParse(dialog2.SizeBox.Text, out int result);
                        Size = result;
                    }
                    dialog2.Close();

                    /*
                    System.Net.IPAddress[] a = Dns.GetHostByName(Dns.GetHostName()).AddressList;
                    string ip = a[0].ToString();
                    MessageBox.Show("The servers IP-Address is: " + ip);
                    */

                    Thread t = new Thread(runServer);
                    t.IsBackground = true;
                    t.Start();

                }
                else
                {
                    Title.Content = "TicTacToe - Client";

                    /*
                    IPDialog dialog2 = new IPDialog();
                    dialog2.ShowDialog();
                    if (dialog2.DialogResult == true)
                    {
                        //int.TryParse(dialog2.IPBox.Text, out int result);
                        //Size = result;
                    }
                    dialog2.Close();
                    */

                    Thread t = new Thread(runClient);
                    t.IsBackground = true;
                    t.Start();

                }
            }
            dialog1.Close();

            
        }

        private void PlayingField_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBox? listBox = sender as ListBox;
            if (listBox != null && listBox.SelectedItem != null)
            {
                // Get the container element for the selected item
                ListBoxItem? selectedItemContainer = listBox.ItemContainerGenerator.ContainerFromItem(listBox.SelectedItem) as ListBoxItem;
                if (selectedItemContainer != null)
                {
                    if(selectedItemContainer.Background != Brushes.LightGreen && selectedItemContainer.Background != Brushes.Pink)
                    {
                        // Set the background color of the container element
                        selectedItemContainer.Background = Brushes.LightGreen;
                        _selectedIndex = PlayingField.SelectedIndex;
                        PlayingField.UnselectAll();
                        clicked.Set();
                    }
                    
                }
            }

        }
    }
}
