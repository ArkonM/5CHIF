/********************************************************************************
** Form generated from reading UI file 'World.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WORLD_H
#define UI_WORLD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_WorldClass
{
public:
    QWidget *centralWidget;
    QComboBox *continentBox;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QComboBox *countryBox;
    QComboBox *cityBox;
    QTableWidget *tableWidget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *WorldClass)
    {
        if (WorldClass->objectName().isEmpty())
            WorldClass->setObjectName(QString::fromUtf8("WorldClass"));
        WorldClass->resize(1162, 681);
        centralWidget = new QWidget(WorldClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        continentBox = new QComboBox(centralWidget);
        continentBox->setObjectName(QString::fromUtf8("continentBox"));
        continentBox->setGeometry(QRect(190, 30, 481, 22));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 30, 91, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 80, 49, 16));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(80, 120, 49, 16));
        countryBox = new QComboBox(centralWidget);
        countryBox->setObjectName(QString::fromUtf8("countryBox"));
        countryBox->setGeometry(QRect(190, 80, 481, 22));
        cityBox = new QComboBox(centralWidget);
        cityBox->setObjectName(QString::fromUtf8("cityBox"));
        cityBox->setGeometry(QRect(190, 120, 481, 22));
        tableWidget = new QTableWidget(centralWidget);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(60, 210, 256, 411));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(190, 170, 151, 24));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(370, 170, 151, 24));
        WorldClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(WorldClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1162, 22));
        WorldClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(WorldClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        WorldClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(WorldClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        WorldClass->setStatusBar(statusBar);

        retranslateUi(WorldClass);

        QMetaObject::connectSlotsByName(WorldClass);
    } // setupUi

    void retranslateUi(QMainWindow *WorldClass)
    {
        WorldClass->setWindowTitle(QCoreApplication::translate("WorldClass", "World", nullptr));
        label->setText(QCoreApplication::translate("WorldClass", "Kontinente", nullptr));
        label_2->setText(QCoreApplication::translate("WorldClass", "L\303\244nder", nullptr));
        label_3->setText(QCoreApplication::translate("WorldClass", "St\303\244dte", nullptr));
        pushButton->setText(QCoreApplication::translate("WorldClass", "Add", nullptr));
        pushButton_2->setText(QCoreApplication::translate("WorldClass", "Delete", nullptr));
    } // retranslateUi

};

namespace Ui {
    class WorldClass: public Ui_WorldClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WORLD_H
